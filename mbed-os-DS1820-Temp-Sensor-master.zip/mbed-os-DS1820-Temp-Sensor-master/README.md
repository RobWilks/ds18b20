# mbed-os-DS1820-Temp-Sensor

Temp sensor: https://www.adafruit.com/product/381

Red, Black Connect to 3v3 and GND, yellow/blue connect to A1. Connect 4k7 from A1 to 3v3.

Prints via terminal 9600baud
